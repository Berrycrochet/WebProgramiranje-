package org.example.streamingsportskihprenosa.data;

import org.springframework.stereotype.Component;
import org.example.streamingsportskihprenosa.Models.Match;
import org.example.streamingsportskihprenosa.Models.Team;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;

@Component
public class DemoData {

    private final List<Team> teams = new ArrayList<>();
    private final List<Match> matches = new ArrayList<>();


    public DemoData() {
       Team t1 = new Team(1L, "Zeljeznicar", "Sarajevo", "Fudbal");
       Team t2 = new Team(2L, "Celik", "Zenica", "Fudbal");
       Team t3 = new Team(3L, "Velez", "Mostar", "Fudbal");

       teams.addAll(List.of(t1, t2, t3));

       String video = "https://www.youtube.com/watch?v=xWkvDKrSZ2k";

       Match m1 = new Match(
               1L,
               "Zeljeznicar - Celik",
               LocalDateTime.of(2026, 10, 20, 18, 0),
               video
       );

        Match m2 = new Match(
                1L,
                "Celik - Velez",
                LocalDateTime.of(2026, 10, 13, 18, 0),
                video
        );

        Match m3 = new Match(
                1L,
                "Zeljeznicar - Velez",
                LocalDateTime.of(2026, 10, 6 , 18, 0),
                video
        );

        addMatch(m1, t1, t2);
        addMatch(m2, t2, t3);
        addMatch(m3, t1, t3);
    }

    private void addMatch(Match match, Team first, Team second) {
        match.getTeams().add(first);
        match.getTeams().add(second);

        first.getMatches().add(match);
        second.getMatches().add(match);

        matches.add(match);
    }

    public List<Team> findAllTeams() {
        return teams;
    }

    public List<Match> findAllMatches() {
        return matches;
    }

    public Match findMatch(Long id) {
        for (Match match : matches) {
            if (match.getId().equals(id)) {
                return match;
            }
        }

        return null;
    }
}
