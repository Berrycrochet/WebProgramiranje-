package org.example.streamingsportskihprenosa.contoller;



import org.example.streamingsportskihprenosa.Models.Match;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.example.streamingsportskihprenosa.data.DemoData;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.*;

public class AppController {

    private final DemoData data;

    public AppController (DemoData data)
    {
        this.data=data;
    }

    //Mapiranje

    @GetMapping("/")
    public String home() { return  " redirect :/matches";}

    @GetMapping({"/matches" , "/a"})
    public String matches(Model model) {
        model.addAttribute("matches", data.findAllMatches());
        return "matches";
    }

    @GetMapping({"/teams", "/b"})
    public String teams(Model model) {
        model.addAttribute("teams", data.findAllTeams());

        return "teams";
    }

    @GetMapping({"/matches/action/{id}","/a/action/{id}"})
    public String action(
            @PathVariable("id") Long id,
            Model model) {

        Match match = requireMatch(id);

        model.addAttribute("match", match);

        return "action";
    }

    @PostMapping({"/matches/action/{id}","/a/action/{id}"})
    public String toggleStream(
            @PathVariable("id") Long id,
            RedirectAttributes redirectAttributes) {

        Match match = requireMatch(id);

        match.setStreaming(!match.isStreaming());

        String message;

        if (match.isStreaming()) {
            message = "Demo prenos je pokrenut.";
        } else {
            message = "Demo prenos je zaustavljen.";
        }

        redirectAttributes.addFlashAttribute("success", message);

        return "redirect:/matches/action/" + id;
    }

    private Match requireMatch(Long id) {

        Match match = data.findMatch(id);

        if (match == null)
        {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Utakmica nije pronadjena."
            );
        }

        return match;
    }
}
